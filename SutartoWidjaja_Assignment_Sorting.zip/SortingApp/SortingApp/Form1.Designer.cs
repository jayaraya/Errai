﻿namespace SortingApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Sorting = new System.Windows.Forms.Button();
            this.QuickSortTextBox = new System.Windows.Forms.RichTextBox();
            this.BubbleSortTextBox = new System.Windows.Forms.RichTextBox();
            this.MergeSortTextBox = new System.Windows.Forms.RichTextBox();
            this.GCFTextBox = new System.Windows.Forms.RichTextBox();
            this.QuickSortLabel = new System.Windows.Forms.Label();
            this.BubbleSortLabel = new System.Windows.Forms.Label();
            this.MergeSortLabel = new System.Windows.Forms.Label();
            this.GCFLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(77, 40);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(283, 20);
            this.textBox1.TabIndex = 0;
            // 
            // Sorting
            // 
            this.Sorting.Location = new System.Drawing.Point(423, 37);
            this.Sorting.Name = "Sorting";
            this.Sorting.Size = new System.Drawing.Size(75, 23);
            this.Sorting.TabIndex = 1;
            this.Sorting.Text = "Sort";
            this.Sorting.UseVisualStyleBackColor = true;
            this.Sorting.Click += new System.EventHandler(this.Sorting_Click);
            // 
            // QuickSortTextBox
            // 
            this.QuickSortTextBox.Location = new System.Drawing.Point(77, 111);
            this.QuickSortTextBox.Name = "QuickSortTextBox";
            this.QuickSortTextBox.Size = new System.Drawing.Size(100, 96);
            this.QuickSortTextBox.TabIndex = 2;
            this.QuickSortTextBox.Text = "";
            // 
            // BubbleSortTextBox
            // 
            this.BubbleSortTextBox.Location = new System.Drawing.Point(222, 111);
            this.BubbleSortTextBox.Name = "BubbleSortTextBox";
            this.BubbleSortTextBox.Size = new System.Drawing.Size(100, 96);
            this.BubbleSortTextBox.TabIndex = 3;
            this.BubbleSortTextBox.Text = "";
            // 
            // MergeSortTextBox
            // 
            this.MergeSortTextBox.Location = new System.Drawing.Point(358, 111);
            this.MergeSortTextBox.Name = "MergeSortTextBox";
            this.MergeSortTextBox.Size = new System.Drawing.Size(100, 96);
            this.MergeSortTextBox.TabIndex = 4;
            this.MergeSortTextBox.Text = "";
            // 
            // GCFTextBox
            // 
            this.GCFTextBox.Location = new System.Drawing.Point(494, 111);
            this.GCFTextBox.Name = "GCFTextBox";
            this.GCFTextBox.Size = new System.Drawing.Size(100, 96);
            this.GCFTextBox.TabIndex = 5;
            this.GCFTextBox.Text = "";
            // 
            // QuickSortLabel
            // 
            this.QuickSortLabel.AutoSize = true;
            this.QuickSortLabel.Location = new System.Drawing.Point(103, 221);
            this.QuickSortLabel.Name = "QuickSortLabel";
            this.QuickSortLabel.Size = new System.Drawing.Size(35, 13);
            this.QuickSortLabel.TabIndex = 6;
            this.QuickSortLabel.Text = "label1";
            // 
            // BubbleSortLabel
            // 
            this.BubbleSortLabel.AutoSize = true;
            this.BubbleSortLabel.Location = new System.Drawing.Point(250, 221);
            this.BubbleSortLabel.Name = "BubbleSortLabel";
            this.BubbleSortLabel.Size = new System.Drawing.Size(35, 13);
            this.BubbleSortLabel.TabIndex = 7;
            this.BubbleSortLabel.Text = "label2";
            // 
            // MergeSortLabel
            // 
            this.MergeSortLabel.AutoSize = true;
            this.MergeSortLabel.Location = new System.Drawing.Point(393, 221);
            this.MergeSortLabel.Name = "MergeSortLabel";
            this.MergeSortLabel.Size = new System.Drawing.Size(35, 13);
            this.MergeSortLabel.TabIndex = 8;
            this.MergeSortLabel.Text = "label3";
            // 
            // GCFLabel
            // 
            this.GCFLabel.AutoSize = true;
            this.GCFLabel.Location = new System.Drawing.Point(524, 221);
            this.GCFLabel.Name = "GCFLabel";
            this.GCFLabel.Size = new System.Drawing.Size(35, 13);
            this.GCFLabel.TabIndex = 9;
            this.GCFLabel.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(241, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Bubble Sort";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(103, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Quick Sort";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(382, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Merge Sort";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(524, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "GCF Sort";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 299);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.GCFLabel);
            this.Controls.Add(this.MergeSortLabel);
            this.Controls.Add(this.BubbleSortLabel);
            this.Controls.Add(this.QuickSortLabel);
            this.Controls.Add(this.GCFTextBox);
            this.Controls.Add(this.MergeSortTextBox);
            this.Controls.Add(this.BubbleSortTextBox);
            this.Controls.Add(this.QuickSortTextBox);
            this.Controls.Add(this.Sorting);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Sorting;
        private System.Windows.Forms.RichTextBox QuickSortTextBox;
        private System.Windows.Forms.RichTextBox BubbleSortTextBox;
        private System.Windows.Forms.RichTextBox MergeSortTextBox;
        private System.Windows.Forms.RichTextBox GCFTextBox;
        private System.Windows.Forms.Label QuickSortLabel;
        private System.Windows.Forms.Label BubbleSortLabel;
        private System.Windows.Forms.Label MergeSortLabel;
        private System.Windows.Forms.Label GCFLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;

        private int QuickSortTime;

        private int BubbleSortTime;

        private int MergeSortTime;

        private int GCFSortTime;
    }
}

