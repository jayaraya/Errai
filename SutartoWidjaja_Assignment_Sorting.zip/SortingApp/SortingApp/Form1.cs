﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SortingApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Sorting_Click(object sender, EventArgs e)
        {
            string myString = textBox1.Text.ToString();
            string[] ElementStr = myString.Split(',');
            int Length = ElementStr.Length - 1;

            int[] ElementInt = Array.ConvertAll(ElementStr, s => int.Parse(s));
            
            var watch1 = new System.Diagnostics.Stopwatch();
            watch1.Start();
            QuickSort(ElementInt, 0, Length);
            watch1.Stop();
            QuickSortTime = Convert.ToInt32(watch1.ElapsedMilliseconds);
            string result1 = string.Join(",", ElementInt);
            QuickSortTextBox.Text = result1;
            string temp1 = QuickSortTime.ToString();
            QuickSortLabel.Text = temp1 + " ms";

            var watch2 = new System.Diagnostics.Stopwatch();
            watch2.Start();
            BubbleSort(ElementInt);
            watch2.Stop();
            BubbleSortTime = Convert.ToInt32(watch2.ElapsedMilliseconds);
            string result2 = string.Join(",", ElementInt);
            BubbleSortTextBox.Text = result2;
            string temp2 = BubbleSortTime.ToString();
            BubbleSortLabel.Text = temp2 + " ms";

            int[] ElementIntMerge;
            var watch3 = new System.Diagnostics.Stopwatch();
            watch3.Start();
            ElementIntMerge = mergeSort(ElementInt);
            watch3.Stop();
            MergeSortTime = Convert.ToInt32(watch3.ElapsedMilliseconds);
            string result3 = string.Join(",", ElementIntMerge);
            MergeSortTextBox.Text = result3;
            string temp3 = MergeSortTime.ToString();
            MergeSortLabel.Text = temp3 + " ms";

         
            var watch4 = new System.Diagnostics.Stopwatch();
            watch4.Start();
            GCF(20, ElementInt);
            watch4.Stop();
            GCFSortTime = Convert.ToInt32(watch4.ElapsedMilliseconds);
            string result4 = string.Join(",", ElementInt);
            GCFTextBox.Text = result4;
            string temp4 = GCFSortTime.ToString();
            GCFLabel.Text = temp4 + " ms";
        }

        private void QuickSort(int[] arr, int start, int end)
        {
            int i;

            

            if (start < end)
            {
                i = Partition(arr, start, end);

                QuickSort(arr, start, i - 1);
                QuickSort(arr, i + 1, end);
            }

            
        }

        private int Partition(int[] arr, int start, int end)
        {
            int temp;
            int p = arr[end];
            int i = start - 1;

            for (int j = start; j <= end - 1; j++)
            {
                if (arr[j] <= p)
                {
                    i++;
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }

            temp = arr[i + 1];
            arr[i + 1] = arr[end];
            arr[end] = temp;
            return i + 1;
        }

        private void BubbleSort(int[] arr)
        {
            int temp;

            for (int j = 0; j <= arr.Length - 2; j++)
            {
                for (int i = 0; i <= arr.Length - 2; i++)
                {
                    if (arr[i] > arr[i + 1])
                    {
                        temp = arr[i + 1];
                        arr[i + 1] = arr[i];
                        arr[i] = temp;
                    }
                }
            }
        }

        public static int[] mergeSort(int[] array)
        {
            int[] left;
            int[] right;
            int[] result = new int[array.Length];

            if (array.Length <= 1)
                return array;              
           
            int midPoint = array.Length / 2;  
           
            left = new int[midPoint];
  
            
            if (array.Length % 2 == 0)
                right = new int[midPoint];  
            else
                right = new int[midPoint + 1];  
          
            for (int i = 0; i < midPoint; i++)
                left[i] = array[i];  
          
            int x = 0;
           
            for (int i = midPoint; i < array.Length; i++)
            {
                right[x] = array[i];
                x++;
            }  
           
            left = mergeSort(left);
            right = mergeSort(right);
            result = merge(left, right);

           

            return result;
        }

        public static int[] merge(int[] left, int[] right)
        {
            int resultLength = right.Length + left.Length;
            int[] result = new int[resultLength];
            //
            int indexLeft = 0, indexRight = 0, indexResult = 0;
            
            while (indexLeft < left.Length || indexRight < right.Length)
            {
                if (indexLeft < left.Length && indexRight < right.Length)
                {
                    if (left[indexLeft] <= right[indexRight])
                    {
                        result[indexResult] = left[indexLeft];
                        indexLeft++;
                        indexResult++;
                    }
                    else
                    {
                        result[indexResult] = right[indexRight];
                        indexRight++;
                        indexResult++;
                    }
                }
                else if (indexLeft < left.Length)
                {
                    result[indexResult] = left[indexLeft];
                    indexLeft++;
                    indexResult++;
                }
                else if (indexRight < right.Length)
                {
                    result[indexResult] = right[indexRight];
                    indexRight++;
                    indexResult++;
                }
            }
            return result;
        }

        private void GCFSort(int[] arr1, int[] arr2, int[] arr3)
        {
            int temp1,temp2,temp3=-1,temp4=-1,temp5;

            for (int j = 0; j <= arr1.Length - 2; j++)
            {
                for (int i = 0; i <= arr1.Length - 2; i++)
                {
                    if (arr1[i] > arr1[i + 1])
                    {
                        temp1 = arr1[i + 1];
                        arr1[i + 1] = arr1[i];
                        arr1[i] = temp1;

                        temp2 = arr2[i + 1];
                        arr2[i + 1] = arr2[i];
                        arr2[i] = temp2;
                    }
                }
            }

            for (int k = 0; k <= arr1.Length - 2; k++)
            {
                for (int m = 0; m <= arr1.Length - 2; m++)
                {
                    if ((arr1[m] == arr1[m + 1]) && (arr2[m] != arr2[m+1]))
                    {
                        for (int n = 0; n < arr1.Length; n++)
                        {
                            if (arr2[m] == arr3[n])
                            {
                                temp3 = n;
                                break;
                            }
                        }
                        for (int p = 0; p < arr1.Length; p++)
                        {
                            if (arr2[m + 1] == arr3[p])
                            {
                                temp4 = p;
                                break;
                            }
                        }

                        if (temp3 > temp4)
                        {
                            temp5 = arr2[m + 1];
                            arr2[m + 1] = arr2[m];
                            arr2[m] = temp5;
                        }
                    }                    
                }               
            }
        }

        private void GCF(int comparenum, int[] b)
        {
            int n = b.Length;
            int result1 = -1, result2 = -1;

            int[] c = new int[n];
            int[] d = new int[n];

            for (int j = 0; j < n; j++)
            {
                for (int i = comparenum; i > 0; i--)
                {

                    result1 = b[j] % i;
                    result2 = comparenum % i;

                    if ((result1 == 0) && (result2 == 0))
                    {
                        c[j] = i;
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
            }

            for (int x = 0; x < n; x++)
            {
                d[x] = b[x];
            }
            GCFSort(c, b, d);       
        }
    }
}
